---
sidebar_position: 13
---

# Set Webhook URL for Paystack

Step 1: Login to paystack Dashboard  
Step 2: Click Settings  
Step 3: Click API keys and webhooks

Copy paypal Webhook from Admin panel  
Settings->System Settings and paste here

![Paystack Step 1](</images/panel/paystack(step1).png>)
