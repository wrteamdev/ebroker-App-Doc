---
sidebar_position: 4
---

# Set Terms Conditions

Set Terms Conditions for your website and app.
![Terms Conditions](/images/panel/terms_conditions.png)
