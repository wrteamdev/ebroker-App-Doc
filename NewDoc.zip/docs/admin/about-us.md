---
sidebar_position: 5
---

# Set About Us

Set and manage your about us content for app.
![About Us](/images/panel/about_us.png)
