---
sidebar_position: 15
---

# Set Webhook URL for Razorpay

Step 1: Login to paystack Dashboard  
Step 2: Click Account Settings  
Step 3: Click webhooks  
Step 4: Click Add New Webhook

![Razorpay Step 1](</images/panel/razorpay(step1).png>)

Copy paypal Webhook from Admin panel  
Settings->System Settings and paste here

![Razorpay Step 2](</images/panel/razorpay(step2).png>)
