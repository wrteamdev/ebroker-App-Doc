---
sidebar_position: 17
---

# Set Webhook URL for Stripe

Step 1: Login to Stripe Dashboard  
Step 2: Click Webhooks  
Step 3: Click Add endpoint

![Stripe Step 1](</images/panel/stripe(step1).png>)

Step 5: click on select events

![Stripe Step 2](</images/panel/stripe(step2).png>)

Step 6: click add events

![Stripe Step 3](</images/panel/Stripe(step3).png>)

Then click on add End Point
