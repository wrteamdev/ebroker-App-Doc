---
sidebar_position: 2
---

# Set System Configurations

## Company Details

![Company Details](/images/panel/company_details.png)

## Payment Details

![Payment Details](/images/panel/payment_details.png)

## More Settings

![More Settings](/images/panel/more_settings.png)

## Image Settings

![Image Settings](/images/panel/image_settings.png)

## App Settings

![App Settings](/images/panel/app_settings.png)

## Web Settings

![Web Settings](/images/panel/web_settings.png)
