---
sidebar_position: 16
---

# Set Keys for Stripe

Step 1: Login to Stripe Dashboard  
Step 2: Click API keys

![Stripe Keys](</images/panel/stripe(keys).png>)

Step 3: Copy publishable key and secret keys and paste it in admin panel system settings

![Stripe Settings](/images/panel/stripe_settings.png)
