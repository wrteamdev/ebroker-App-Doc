---
sidebar_position: 9
---

# Firebase Billing

Link:- [Firebase Billing](https://www.youtube.com/embed/RuJuBCYjmhc?si=KQzlgsItU3MiFaUJ)
