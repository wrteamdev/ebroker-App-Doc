---
sidebar_position: 20
---

# Update System Version

:::warning
Please Take a Backup of your current version code and database.  
Before Update Take a look for Instructions.txt file in update folder.
:::

Step 1: Go to System update  
Step 2: Enter Your Purchase Code  
Step 3: Upload Zip file (current*version)\_to*(latest_version).zip from update folder.

![System Version](/images/panel/system_version.png)
