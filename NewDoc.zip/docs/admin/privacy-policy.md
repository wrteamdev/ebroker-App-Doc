---
sidebar_position: 3
---

# Set Privacy Policy

Set Privacy Policy for your website and app.
![Privacy Policy](/images/panel/privacy_policy.png)
