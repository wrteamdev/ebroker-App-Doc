---
sidebar_position: 10
---

# Set Keys for Paypal

Step 1: Login to Paypal Dashboard  
Step 2: Go to Account Settings -> Account Owner Information  
Step 3: click on update in email section

![Paypal Keys 1](/images/panel/paypalkey1.png)

here is your business email

![Paypal Keys 2](/images/panel/paypalkeys2.png)

Step 4: Copy Email and paste it in admin panel system settings

![Paypal Settings](/images/panel/paypal_settings.png)
