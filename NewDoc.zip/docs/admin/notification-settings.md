---
sidebar_position: 8
---

# Notification Settings

![Notification Settings](/images/panel/notification-settings-panel.png)

Update Project Id and Service JSON File

## Get Project ID

Go to Firebase -> Project -> Project Settings -> General
![Project ID Firebase](/images/panel/project-id-firebase.png)

## Get Service JSON File

Go to Firebase -> Project -> Project Settings -> Service Accounts
![Service JSON File Firebase](/images/panel/service-json-file-firebase.png)
