---
sidebar_position: 21
---

# Support

Delighted to serve and support you! Contact our support team led by Shakir Memon on [Teams](https://teams.live.com/l/invite/FEAN_7C4kzeomJM8gE)

To help our customers, we constantly be in touch with every customer if they need any assistance regarding our product. We offer our customers a support from **Mon – Fri 9.00 AM to 6.00 PM IST (GMT +5.30) – We are a Team located in India – Asia.**

Typically we reply our customers for all the questions and queries within 24 hours of time via comments, support forum or emails.
