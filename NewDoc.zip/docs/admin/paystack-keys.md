---
sidebar_position: 12
---

# Set Keys for Paystack

Step 1: Login to Paystack Dashboard  
Step 2: Go to get Started section you can find Your Test Keys Section

![Paystack Keys](/images/panel/ps_keys.png)

Step 3: Copy Test secret key and Test Public Key and paste it in admin panel system settings

![Paystack Settings](/images/panel/ps_settings.png)
