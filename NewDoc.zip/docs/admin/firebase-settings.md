---
sidebar_position: 6
---

# Firebase Settings

Go to your web firebase project->settings->General
![Firebase Settings](/images/panel/firebase_settings.png)

Copy One by one Configuration values From this Section and add in Admin Panel -> Settings -> Firebase Settings
![System Firebase Settings](/images/panel/system_firebase_settings.png)
